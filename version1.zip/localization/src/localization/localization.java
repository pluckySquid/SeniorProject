package localization;
import java.sql.Connection;
import java.sql.*;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import javax.swing.*;
import javax.swing.JFrame;


public class localization {
	static int action ;
	public static void main(String[] args) {
		menue();
		if(action == 3)
			deleteDatabase();
		else {
		drawOnGraph s = new drawOnGraph();
		s.getHistoryMovement(action);
		JFrame f = new JFrame();
		f.add(s);
		f.setVisible(true);
		f.setSize(1000, 600);
		f.setTitle("Moving human");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}

	}
	
	public static void menue() {
		System.out.println("Doing you want to track realtime movement or Checking history movement?");
		System.out.println("1..............realtime");
		System.out.println("2..............movement history");
		System.out.println("3..............delete database history");
		Scanner keyboard = new Scanner(System.in);
		action = keyboard.nextInt();
		
	}
	
	public static void deleteDatabase() {
		String myUrl = "jdbc:mysql://localhost:3306/accelerationdatabase";
		  Connection conn = null;
			  
		    try
		    {
			      conn = DriverManager.getConnection(myUrl, "root", "yunshu");
			      Statement myStmt = conn.createStatement();
			      ResultSet myRs =  myStmt.executeQuery("truncate acc2");
			      System.out.println("All data in the database has been delete!");
			      menue();
		    }catch (Exception e)
		    {
			      System.err.println("Got an exception!");
			      System.err.println(e.getMessage());
			    }
			    finally{
			    	 if(conn!=null)
						try {
							conn.close();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			    	}
	}
	
	
	
}

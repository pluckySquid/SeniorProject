package localization;
import javax.swing.*;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.*;


public class drawOnGraph extends JPanel implements ActionListener{
	  Timer t = new Timer (20, this);
	  double x = 0, y = 0;
	  double coefficient = 100;
	  protected int historyMovement = 1;
	  int count = 1;

		  //double velX = 0, velY = 0;
	  
	  public void paintComponent(Graphics g) {
		  super.paintComponent(g);
		  Graphics2D g2 = (Graphics2D) g;
		  Ellipse2D circle  = new Ellipse2D.Double(x+500, y+300, 15, 15);
		  g2.fill(circle);
		  t.start();
		  
	  }
	  
	  public void actionPerformed(ActionEvent e) {
		  if(historyMovement == 1) {
			  readFromDatabase currentLocation = new readFromDatabase();
			  double newX = currentLocation.getDistanceX() * coefficient;
			  double newY = currentLocation.getDistanceY() * coefficient;
			  if(newX < 500 && newX > -500)
			  x = newX;
			  if(newY < 300 && newY > -290)
			  y = newY;
			  repaint();
		  }
		  if(historyMovement == 2 ) {
			  readHistory currentLocation = new readHistory();
			  if(currentLocation.getDistanceX(count) * coefficient < 1000 && currentLocation.getDistanceX(count) * coefficient > 0)
			  x = currentLocation.getDistanceX(count) * coefficient;
			  if(currentLocation.getDistanceY(count) * coefficient < 1000 && currentLocation.getDistanceY(count) * coefficient > 0)
			  y = currentLocation.getDistanceY(count) * coefficient;
			  repaint();
			  count++;
		  }
	  }
	  public void getHistoryMovement (int h) {
		  historyMovement = h;
	  }

	 
	  
	 // public double getXLocation() {
		  //double Xlocation = currentLocation.getDistanceX();
		//return Xlocation;
	 // }
	  
//	  public double getYLocation() {
//		  double Ylocation = currentLocation.getDistanceY();
//		return Ylocation;
//	  }
//	  
//	  public static void getLoc() {
//			while(true) {
//			currentLocation.changeLocation();
//			}
//		}
	  
	  
	  
}